package UnitTests;

import junit.framework.TestCase;

public class JunitSpelerVerwerkerTest extends TestCase {

}
