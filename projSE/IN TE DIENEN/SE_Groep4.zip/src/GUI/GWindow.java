package GUI;

public abstract class GWindow {
	public abstract void show();
}